/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_split_test.c                                    :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/23 09:44:15 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 11:06:04 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	split_begins_and_ends_with_c()
{
	char		*s = strdup("***Begins*and*ends*with*c*");
	const char	c = '*';
	char		**result;

	printf("source [s]   : [%s]\n", s);
	printf("character [c]: [%c]\n\n", c);
	
	printf("expected     : [Begins] [and] [ends] [with] [c] [(null)]\n");
	result = ft_split(s, c);
	printf("ft_split     : [%s] [%s] [%s] [%s] [%s] [%s]\n", result[0], result[1], result[2], result[3], result[4], result[5]);

	free(result);
	free(s);
}

void	split_multiple_c_in_a_row()
{
	char		*s = strdup("Multiple***c's****in**a*row");
	const char	c = '*';
	char		**result;

	printf("source [s]   : [%s]\n", s);
	printf("character [c]: [%c]\n\n", c);
	
	printf("expected     : [Multiple] [c's] [in] [a] [row] [(null)]\n");
	result = ft_split(s, c);
	printf("ft_split     : [%s] [%s] [%s] [%s] [%s] [%s]\n\n", result[0], result[1], result[2], result[3], result[4], result[5]);

	free(result);
	free(s);
}

void	split_basic()
{
	char		*s = strdup("Split*on*stars");
	const char	c = '*';
	char		**result;

	printf("source [s]   : [%s]\n", s);
	printf("character [c]: [%c]\n\n", c);
	
	printf("expected     : [Split] [on] [stars] [(null)]\n");
	result = ft_split(s, c);
	printf("ft_split     : [%s] [%s] [%s] [%s]\n\n", result[0], result[1], result[2], result[3]);

	free(result);
	free(s);
}

int	ft_split_test(void)
{
	printf("------------------------------\n");
	printf("    ft_split                  - allocates memory and returns an array of strings obtained by splitting [s] on the character [c]. The array must end with a NULL pointer.\n\n");
	
	split_basic();
	split_multiple_c_in_a_row();
	split_begins_and_ends_with_c();
	
	printf("------------------------------\n\n");
	return (0);
}

