/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_striteri_test.c                                 :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/24 11:52:55 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 12:09:11 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

static void	my_function(unsigned int n, char *c)
{
	if ((*c >= 'a' && *c <= 'z') && n % 2 == 1)
	{
		*c = *c - 32;
	}
}

void	striteri_basic()
{
	char	*s = strdup("apply the function to every character of the [s] string");

	printf("source [s]   : [%s]\n", s);
	printf("function [f] : Capitalizes every other letter of the string\n\n");
	
	printf("expected     : [aPpLy tHe fUnCtIoN To eVeRy cHaRaCtEr oF ThE [s] StRiNg]\n");
	ft_striteri(s, my_function);
	printf("ft_split     : [%s]\n\n", s);

	free(s);
}

int	ft_striteri_test(void)
{
	printf("------------------------------\n");
	printf("    ft_striteri               - applies function [f] to each char of [s]. Returns [s] after successive applications of [f]\n\n");
	
	striteri_basic();
	
	printf("------------------------------\n\n");
	return (0);
}
