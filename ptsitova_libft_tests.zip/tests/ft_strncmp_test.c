/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strncmp_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:42:58 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/28 09:47:15 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

static void	strncmp_basic()
{
	const char	s1[] = "AbCdeFg";
	const char	s2[] = "AbCdefg";
	
	printf("source [s1]   : [%s] - basic check\n", s1);
	printf("source [s2]   : [%s]\n", s2);
	printf("to compare [n]: [7]\n\n");
	
	printf("strncmp       : [%d]\n", strncmp(s1, s2, 7));
	printf("ft_strncmp    : [%d]\n\n", ft_strncmp(s1, s2, 7));
	printf("---\n\n");
}

static void	strncmp_same_strings()
{
	const char	s1[] = "aaa";
	const char	s2[] = "aaa";
	
	printf("source    [s1]: [%s] - same strings\n", s1);
	printf("source    [s2]: [%s]\n", s2);
	printf("to compare [n]: [7]\n\n");
	
	printf("strncmp       : [%d]\n", strncmp(s1, s2, 7));
	printf("ft_strncmp    : [%d]\n\n", ft_strncmp(s1, s2, 7));
	printf("---\n\n");
}

static void	strncmp_compare_zero_char()
{
	const char	s1[] = "aaa";
	const char	s2[] = "aaa";
	
	printf("source [s1]   : [%s] - compare 0 characters\n", s1);
	printf("source [s2]   : [%s]\n", s2);
	printf("to compare [n]: [0]\n\n");
	
	printf("strncmp       : [%d]\n", strncmp(s1, s2, 0));
	printf("ft_strncmp    : [%d]\n\n", ft_strncmp(s1, s2, 0));
	printf("---\n\n");
}

static void	strncmp_unsigned_char_test()
{
	const char	s1[] = "test\200";
	const char	s2[] = "test\0";
	
	printf("source [s1]   : [%s] - !unsigned char! test\n", s1);
	printf("source [s2]   : [%s]\n", s2);
	printf("to compare [n]: [6]\n\n");
	
	printf("strncmp       : [%d]\n", strncmp(s1, s2, 6));
	printf("ft_strncmp    : [%d]\n\n", ft_strncmp(s1, s2, 6));
}

int	ft_strncmp_test(void)
{
	printf("------------------------------\n");
	printf("    ft_strncmp                - compares two strings. The comparison is done using unsigned characters. Returns 0 if s1 == s2, <0 if s1<s2 & >0 if s1>s2\n\n");
	
	strncmp_basic();
	strncmp_same_strings();
	strncmp_compare_zero_char();
	strncmp_unsigned_char_test();
	
	printf("------------------------------\n\n");
	return (0);
}
