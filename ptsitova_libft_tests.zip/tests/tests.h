#ifndef LIBFT_TESTS_H
#define LIBFT_TESTS_H

#include "../libft.h"

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <ctype.h>

#ifdef linux
#include <bsd/string.h>
#else
#include <string.h>
#endif

int	ft_atoi_test();
int	ft_bzero_test();
int	ft_calloc_test();
int	ft_isalnum_test();
int	ft_isalpha_test();
int	ft_isascii_test();
int	ft_isdigit_test();
int	ft_isprint_test();
int	ft_itoa_test();
int ft_memchr_test();
int	ft_memcmp_test();
int	ft_memcpy_test();
int	ft_memmove_test();
int	ft_memset_test();
int	ft_putchar_fd_test();
int	ft_putendl_fd_test();
int	ft_putnbr_fd_test();
int	ft_putstr_fd_test();
int	ft_split_test();
int	ft_strchr_test();
int	ft_strdup_test();
int	ft_striteri_test();
int	ft_strjoin_test();
int	ft_strlcat_test();
int	ft_strlcpy_test();
int	ft_strlen_test();
int	ft_strmapi_test();
int	ft_strncmp_test();
int	ft_strnstr_test();
int	ft_strrchr_test();
int	ft_strtrim_test();
int	ft_substr_test();
int	ft_tolower_test();
int	ft_toupper_test();

#endif


