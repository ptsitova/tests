/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strjoin_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/23 09:03:14 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/28 10:24:16 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	strjoin_basic()
{
	char	*s1 = strdup("abcdefghijklmnopqrstuvwxyz");
	char	*s2 = strdup("Hello");
	char	*result;

	result = ft_strjoin(s2, s1);

	printf("[s1] & len: [%s] [%zu] - basic check\n", s1, strlen(s1));
	printf("[s2] & len: [%s] [%zu]\n\n", s2, strlen(s2));
	
	printf("expected  : [%s%s]\n", s2, s1);
	printf("ft_strjoin: [%s]\n\n", result);
	printf("---\n\n");
	free(result);
	free(s1);
	free(s2);
}
void	strjoin_empty_s1()
{
	char	*s1 = strdup("");
	char	*s2 = strdup("def");
	char	*result;

	result = ft_strjoin(s1, s2);

	printf("[s1] & len: [%s] [%zu] - empty s1\n", s1, strlen(s1));
	printf("[s2] & len: [%s] [%zu]\n\n", s2, strlen(s2));
	
	printf("expected  : [%s%s]\n", s1, s2);
	printf("ft_strjoin: [%s]\n\n", result);
	printf("---\n\n");
	free(result);
	free(s1);
	free(s2);
}

void	strjoin_empty_s2()
{
	char	*s1 = strdup("abc");
	char	*s2 = strdup("");
	char	*result;

	result = ft_strjoin(s1, s2);

	printf("[s1] & len: [%s] [%zu] - empty s2\n", s1, strlen(s1));
	printf("[s2] & len: [%s] [%zu]\n\n", s2, strlen(s2));
	
	printf("expected  : [%s%s]\n", s1, s2);
	printf("ft_strjoin: [%s]\n\n", result);
	printf("---\n\n");
	free(result);
	free(s1);
	free(s2);
}

void	strjoin_same_string()
{
	char	*s1 = strdup("klmnopqrstuvwxyz");
	char	*s2 = &s1[5];
	char	*result;

	result = ft_strjoin(s2, s1);

	printf("[s1] & len: [%s] [%zu] - s1 and s2 are the same string\n", s1, strlen(s1));
	printf("[s2] & len: [%s] [%zu]\n\n", s2, strlen(s2));
	
	printf("expected  : [%s%s]\n", s2, s1);
	printf("ft_strjoin: [%s]\n\n", result);
	free(result);
	free(s1);
}

int	ft_strjoin_test(void)
{
	printf("------------------------------\n");
	printf("    ft_strjoin                - allocates memory (using malloc) and returns a new string, which is the result of concatenating [s1] and [s2]\n\n");
	
	strjoin_basic();
	strjoin_empty_s1();
	strjoin_empty_s2();
	strjoin_same_string();
	
	printf("------------------------------\n\n");
	return (0);
}
