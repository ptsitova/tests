/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_isascii_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:26:37 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_isascii_test(void)
{
	unsigned char	c;
	int		i;
	
	i = 127;
	c = 127;
	printf("------------------------------\n");
	printf("    ft_isascii                - checks if [c] belongs to the ASCII character set. Return values are nonzero if [c] falls into the tested class, and zero if not.\n\n");
	
	printf("char [c]  : %c\n", c);
	printf("dec [c]   : %d\n\n", i);
	
	printf("isascii   : %d\n", isascii(c));
	printf("ft_isascii: %d\n\n", ft_isascii(c));
	c = 199;
	i = 199;
	printf("source [c]: %c\n", c);
	printf("dec [c]   : %d\n\n", i);
	printf("isdigit   : %d\n", isdigit(c));
	printf("ft_isdigit: %d\n", ft_isdigit(c));
	
	printf("------------------------------\n\n");
	return (0);
}
