/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strmapi_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/24 11:08:35 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 11:48:33 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

static char	my_function(unsigned int n, char c)
{
	if ((c >= 'a' && c <= 'z') && n % 2 == 1)
	{
		c = c - 32;
	}
	return (c);
}

void	strmapi_basic()
{
	char	*s = strdup("apply the function to every character of the [s] string");
	char		*result;

	printf("source [s]   : [%s]\n", s);
	printf("function [f] : Capitalizes every other letter of the string\n\n");
	
	printf("expected     : [aPpLy tHe fUnCtIoN To eVeRy cHaRaCtEr oF ThE [s] StRiNg]\n");
	result = ft_strmapi(s, my_function);
	printf("ft_split     : [%s]\n\n", result);

	free(result);
	free(s);
}

int	ft_strmapi_test(void)
{
	printf("------------------------------\n");
	printf("    ft_strmapi                - applies function [f] to each char of [s]. Returns new string, created using malloc, after successive applications of [f]\n\n");
	
	strmapi_basic();
	
	printf("------------------------------\n\n");
	return (0);
}
