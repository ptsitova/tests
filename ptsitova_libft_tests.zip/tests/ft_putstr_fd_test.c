/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_putstr_fd_test.c                                :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/24 13:38:27 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 13:54:54 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	putstr_fd_basic()
{
	char	*s = strdup("What is a file descriptor?");
	int		file_descriptor;

	file_descriptor = 1;
	printf("source [s]          : [%s]\n", s);
	printf("file descriptor [fd]: [%d]\n\n", file_descriptor);
	
	printf("expected     : \n%s\n", s);
	printf("ft_putstr_fd: \n");
	ft_putstr_fd(s, file_descriptor);
	printf("\n");
	free(s);
}

int	ft_putstr_fd_test(void)
{
	printf("------------------------------\n");
	printf("    ft_putstr_fd             - outputs the string [s] to the specified file descriptor.\n\n");
	
	putstr_fd_basic();
	
	printf("------------------------------\n\n");
	return (0);
}
