/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_bzero_test.c                                    :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:24:14 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/30 13:56:07 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void replace_nulls_with_zeros(char* str, size_t slen)
{
	size_t	i;

	i = 0;
	while (i < slen)
	{
        if (str[i] == '\0')
		{
			str[i] = '0';
		}
		i++;
	}
}

static void	bzero_basic()
{
	char			str1[22] = "Well done! Keep going.";
	char			str2[22] = "Well done! Keep going.";
	const size_t	n = 3;
	const size_t	slen = ft_strlen(str1);

	printf("source   : %s\n", str1);
	printf("start    : %s\n", str1 + 2);
	printf("n        : %zu\n\n", n);

	bzero(str1 + 2, n);
	printf("bzero    : %s\n", str1);
	ft_bzero(str2 + 2, n);
	printf("ft_bzero : %s\n\n", str2);
	printf("---\n\n");

	replace_nulls_with_zeros(str1, slen);
	printf("check_sys: %s\n", str1);
	replace_nulls_with_zeros(str2, slen);
	printf("check_ft : %s\n", str2);
}

int	ft_bzero_test(void)
{
	printf("------------------------------\n");
	printf("    ft_bzero                  - erases [n] bytes of memory at the location pointed to by [s], by writing 0s\n\n");
	bzero_basic();
	printf("------------------------------\n\n");
	return (0);
}
