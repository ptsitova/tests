/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strlcpy_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:39:45 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/11/03 12:17:45 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"
#include <unistd.h>

int	ft_strlcpy_test(void)
{
	const char	src[] = "Have a nice day!";
	const char	empt[] = "";
	char		dest1[31] = "Hello people. ";
	char		dest2[31] = "Hello people. ";
	size_t		n = 10;

	printf("------------------------------\n");
	printf("    ft_strlcpy                - copies up to [size-1] characters from the NUL-terminated string [src] to [dst], NUL-terminating the result. Return the total length tried to create.\n\n");
	
	printf("source     : [%s] - strlen: %zu\n", src, strlen(src));
	printf("destination: [%s]   - strlen: %zu\n\n", dest1, strlen(dest1));

	printf("bytes [n]  : %zu - basic test\n\n", n);
	
	printf("strlcpy    : %zu [%s]\n", strlcpy(dest2, src, n), dest2);
	printf("ft_strlcpy : %zu [%s]\n\n", ft_strlcpy(dest1, src, n), dest1);
	n = 0;
	printf("bytes [n]  : %zu - tests if n is 0\n\n", n);
	
	printf("strlcpy    : %zu [%s]\n", strlcpy(dest2, src, n), dest2);
	printf("ft_strlcpy : %zu [%s]\n\n", ft_strlcpy(dest1, src, n), dest1);
	n = -1;
	printf("bytes [n]  : %zu - tests if the n is -1 (becomes MAX SIZE_T)\n\n", n);
#ifdef linux
	printf("strlcpy    : %zu [%s]\n", strlcpy(dest2, src, n), dest2);
#endif
	printf("ft_strlcpy : %zu [%s]\n\n", ft_strlcpy(dest1, src, n), dest1);
	n = 20;
	printf("bytes [n]  : %zu - tests if the src is empty\n\n", n);
#ifdef linux
	printf("strlcpy    : %zu [%s]\n", strlcpy(dest2, empt, n), dest2);
#endif
	printf("ft_strlcpy : %zu [%s]\n\n", ft_strlcpy(dest1, empt, n), dest1);
	
	printf("------------------------------\n\n");
	return (0);
}
