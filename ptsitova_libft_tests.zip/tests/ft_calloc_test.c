/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_calloc_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/21 11:28:16 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/11/03 12:05:11 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void replace_null_with_zero(char* str, size_t slen)
{
	size_t	i;

	i = 0;
	while (i <= slen)
	{
        if (str[i] == '\0')
		{
			str[i] = '0';
		}
		i++;
	}
}

int	ft_calloc_test()
{
	size_t		count;
	size_t		size;
	char		*result;
	
	count = 3;
	size = 2 * sizeof(char);

	printf("------------------------------\n");
	printf("    ft_calloc                 - contiguously allocates space for [count] objects that are [size] bytes of memory each. Returns a pointer to the allocated memory, filled with bytes of value zero\n\n");
	
	printf("[count]  : %zu\n", count);
	printf("[size]   : %zu\n\n", size);
	
	result = calloc(count, size);
	printf("calloc   : %s\n", result);
	replace_null_with_zero(result, (count * size) - 1);
	printf("check_sys: %s\n\n", (char *)result);
	free(result);
	
	result = ft_calloc(count, size);
	if (result == NULL)
	{
		printf("ft_calloc: allocation failed (NULL returned)\n");
		return (1);
	}
	printf("ft_calloc: %s\n", result);
	replace_null_with_zero(result, (count * size) - 1);
	printf("check_ft : %s\n", (char *)result);
	free(result);
	
	printf("------------------------------\n\n");
	return (0);
}
