/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strdup_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/20 17:22:45 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_strdup_test(void)
{
	const char	*str = "Hello malloc";
	char		*result;
	
	
	printf("------------------------------\n");
	printf("    ft_strdup                 - returns a pointer to a new string which is a duplicate of the string [s]. Uses malloc and free. Returns NULL if insufficient memory was available\n\n");
	
	printf("source   : %s\n\n", str);
	result = strdup(str);
	printf("strdup   : %s\n", result);
	free(result);
	result = ft_strdup(str);
	printf("ft_strdup: %s\n", result);
	free(result);
	// printf("source : %s\n\n", str1);
	
	// printf("strdup   : %d\n", strdup(str1));
	// printf("ft_strdup: %d\n", ft_strdup(str1));
	
	printf("------------------------------\n\n");
	return (0);
}
