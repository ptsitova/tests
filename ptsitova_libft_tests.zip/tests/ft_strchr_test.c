/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strchr_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/20 09:54:47 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/27 16:04:23 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_strchr_test(void)
{
	char	*s = strdup("This is a string");
	int		c;

	c = 's';
	printf("------------------------------\n");
	printf("    ft_strchr                 - returns a pointer to the first occurrence of the character [c] in the string [s]\n\n");

	printf("source [s]   : %s\n\n", s);
	
	printf("character [c]: %c\n\n", c);
	
	printf("strchr       : %s\n", strchr(s, c));
	printf("ft_strchr    : %s\n\n", ft_strchr(s, c));
	c = 'z';
	printf("character [c]: %c\n\n", c);
	
	printf("strchr       : %s\n", strchr(s, c));
	printf("ft_strchr    : %s\n\n", ft_strchr(s, c));
	c = 0;
	printf("character [c]: %c\n\n", c);
	
	printf("strchr       : %s\n", strchr(s, c));
	printf("ft_strchr    : %s\n\n", ft_strchr(s, c));
	c = 372;
	printf("character [c]: %c\n\n", c);
	
	printf("strchr       : %s\n", strchr(s, c));
	printf("ft_strchr    : %s\n\n", ft_strchr(s, c));
	
	printf("------------------------------\n\n");
	return (0);
}
