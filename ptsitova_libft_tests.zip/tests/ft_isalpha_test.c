/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_isalpha_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 11:57:09 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_isalpha_test(void)
{
	unsigned char	c;

	c = 'a';
	printf("------------------------------\n");
	printf("    ft_isalpha                - checks for an alphabetic character. Return values are nonzero if [c] falls into the tested class, and zero if not.\n\n");
	
	printf("source [c]: %c\n\n", c);
	
	printf("isalpha   : %d\n", isalpha(c));
	printf("ft_isalpha: %d\n", ft_isalpha(c));
	
	printf("------------------------------\n\n");
	return (0);
}

// // #include <locale.h>

// int	ft_isalphatest()
// {
// 	unsigned char	c = 'a';
// 	// unsigned int p;

// 	// locale_t de = newlocale (LC_ALL, "en_EN.UTF-8", (locale_t) 0);
// 	// setlocale(LC_ALL, "de_DE.UTF-8");
// 	// c = 'ö';
// 	// printf("%d\n", *c);

// 	// p = isalpha_l(c, de);
// 	// printf("%d\n", p);
// 	return (0);
// }

// int	ft_isalphatest(int argc, char *argv[])
// {
// 	if (argc > 0)
// 	{
// 		printf("isalpha   : %d\n", isalpha(argv[1][0]));
// 		printf("ft_isalpha: %d\n", ft_isalpha(argv[1][0]));
// 	}
// 	return (0);
// }