/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_putnbr_fd_test.c                                :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/24 14:02:48 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 14:23:15 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	putnbr_fd_basic()
{
	int	n;
	int	file_descriptor;

	n = 0;
	file_descriptor = 1;
	printf("source [n]          : [%d]\n", n);
	printf("file descriptor [fd]: [%d]\n\n", file_descriptor);
	
	printf("expected    : \n%d\n", n);
	printf("ft_putnbr_fd: \n");
	ft_putnbr_fd(n, file_descriptor);
	printf("\n");
}

int	ft_putnbr_fd_test(void)
{
	printf("------------------------------\n");
	printf("    ft_putnbr_fd              - outputs the integer [n] to the specified file descriptor followed by a newline\n\n");
	
	putnbr_fd_basic();
	
	printf("------------------------------\n\n");
	return (0);
}
