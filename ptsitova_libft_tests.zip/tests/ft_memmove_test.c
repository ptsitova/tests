/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_memmove_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:35:29 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_memmove_test(void)
{
	char	str0[] = "You can do it Polina!";
	char	str1[] = "You can do it Polina!";
	char	str2[] = "You can do it Polina!";
	char	str3[] = "You can do it Polina!";
	int		n;
	
	printf("------------------------------\n");
	printf("    ft_memmove                - copies [n] bytes from memory area [src] to [dest]. The memory areas may overlap!!! Returns a pointer to [dest]\n\n");

	printf("source            : %s\n\n", str0);
	
	printf("start str[2]      : %s\n", str0 + 2);
	printf("dest str[1]       : %s\n", str0 + 1);
	n = 4;
	printf("bytes[n]          : %d\n\n", n);
	
	printf("memmove [s > d]   : %s\n", (char *)memmove(str0 + 1, str0 + 2, 4 * sizeof(char)));
	printf("ft_memmove [s > d]: %s\n\n", (char *)ft_memmove(str1 + 1, str1 + 2, 4 * sizeof(char)));

	printf("start str[0]      : %s\n", str2);
	printf("dest str[4]       : %s\n", str2 + 4);
	n = 6;
	printf("bytes[n]          : %d\n\n", n);
	
	printf("memmove [s < d]   : %s\n", (char *)memmove(str2 + 4, str2, 6 * sizeof(char)));
	printf("ft_memmove [s < d]: %s\n\n", (char *)ft_memmove(str3 + 4, str3, 6 * sizeof(char)));
	
	printf("------------------------------\n\n");
	return (0);
}
