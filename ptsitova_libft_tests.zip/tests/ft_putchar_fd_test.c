/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_putchar_fd_test.c                               :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/24 12:34:57 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 13:33:28 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	putchar_fd_basic()
{
	char	c;
	int		file_descriptor;

	c = 'o';
	file_descriptor = 1;
	printf("character [c]       : [%c]\n", c);
	printf("file descriptor [fd]: [%d]\n\n", file_descriptor);
	
	printf("expected     : \n%c\n", c);
	printf("ft_putchar_fd: \n");
	ft_putchar_fd(c, file_descriptor);
	printf("\n");
}

int	ft_putchar_fd_test(void)
{
	printf("------------------------------\n");
	printf("    ft_putchar_fd             - outputs the character [c] to the specified file descriptor.\n\n");
	
	putchar_fd_basic();
	
	printf("------------------------------\n\n");
	return (0);
}
