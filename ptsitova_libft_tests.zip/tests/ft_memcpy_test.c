/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_memcpy_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:34:13 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/30 13:37:03 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_memcpy_test(void)
{
	char	str0[] = "can do it Polina!";
	char	str1[] = "can do it Polina!";
	const int	n = 3;

	printf("------------------------------\n");
	printf("    ft_memcpy                 - copies [n] bytes from memory area [src] to [dest]. The memory areas must not overlap. Returns a pointer to [dest]\n\n");
	
	printf("source     : %s\n", str0);
	printf("start [src]: %s\n", str0 + 2);
	printf("copied [n] : %d\n\n", n);
	
	memcpy(str0 + 2, str0, n * sizeof(char));
	printf("memcpy     : %s\n", str0);
	ft_memcpy(str1 + 2, str1, n * sizeof(char));
	printf("ft_memcpy  : %s\n\n", str1);
	
	char	str2[] = "123456789";
	char	str3[] = "copythis";
	char	str4[] = "123456789";
	char	str5[] = "copythis";
	const int	m = 5;
	printf("destin     : %s\n", str2);
	printf("start [src]: %s\n", str3);
	printf("copied [n] : %d\n\n", m);
	
	memcpy(str2, str3, m * sizeof(char));
	printf("memcpy     : %s\n", str2);
	ft_memcpy(str4, str5, m * sizeof(char));
	printf("ft_memcpy  : %s\n\n", str4);

	// char *s1 = "how about normal letters";
	// char *s2 = "45+98535and some numbers too";
	// char *s3 = "how about normal letters";
	// char *s4 = "45+98535and some numbers too";
	// int size = 8;
	
	// memcpy(s1, s2, size);
	// printf("memcpy     : %s\n", s1);
	// ft_memcpy(s3, s4, size);
	// printf("ft_memcpy  : %s\n\n", s3);

	// // memcpy((void *)0, (void *)0, 3);
	// // printf("memcpy     : %s\n", s1);
	// ft_memcpy((void *)0, (void *)0, 3);
	// printf("ft_memcpy  : %s\n\n", s3);
	
	printf("------------------------------\n\n");
	return (0);
}
