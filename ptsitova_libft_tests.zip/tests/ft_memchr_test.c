/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_memchr_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/20 12:03:38 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/30 14:12:19 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	memchr_basic()
{
	void	*s = strdup("This is a string");

	printf("source [s]   : [%s] - basic check\n", (char *)s);
	printf("character [c]: [%c]\n", 's');
	printf("mem bytes [n]: [%d]\n\n", 3);
	
	printf("memchr       : [%s]\n", (char *)memchr(s, 's', 3));
	printf("ft_memchr    : [%s]\n\n", (char *)ft_memchr(s, 's', 3));
	printf("---\n\n");
}

void	memchr_checks_zero_bytes()
{
	void	*s = strdup("This is a string");

	printf("source [s]   : [%s] - checks 0 bytes\n", (char *)s);
	printf("character [c]: [%c]\n", 's');
	printf("mem bytes [n]: [%d]\n\n", 0);
	
	printf("memchr       : [%s]\n", (char *)memchr(s, 's', 0));
	printf("ft_memchr    : [%s]\n\n", (char *)ft_memchr(s, 's', 0));
	printf("---\n\n");
}

void	memchr_char_is_null()
{
	void	*s = strdup("This is a string");

	printf("source [s]   : [%s] - if character is 0\n", (char *)s);
	printf("character [c]: [%c]\n", 0);
	printf("mem bytes [n]: [%d]\n\n", 1);
	
	printf("memchr       : [%s]\n", (char *)memchr(s, 0, 1));
	printf("ft_memchr    : [%s]\n\n", (char *)ft_memchr(s, 0, 1));
	printf("---\n\n");
}

void	memchr_checks_unsigned_char()
{
	void	*s = strdup("This is a string");

	printf("source [s]   : [%s] - checks unsigned char\n", (char *)s);
	printf("character [c]: [%c]\n", 371);
	printf("mem bytes [n]: [%d]\n\n", 10);
	
	printf("memchr       : [%s]\n", (char *)memchr(s, 371, 10));
	printf("ft_memchr    : [%s]\n\n", (char *)ft_memchr(s, 371, 10));
}

int	ft_memchr_test(void)
{
	printf("------------------------------\n");
	printf("    ft_memchr                 - scans the initial [n] bytes of the memory pointed to by [s] for the first instance of [c]. Returns a pointer to the matching byte or NULL if the character does not occur in the given memory area.\n\n");

	memchr_basic();
	memchr_checks_zero_bytes();
	memchr_char_is_null();
	memchr_checks_unsigned_char();
	
	printf("------------------------------\n\n");
	return (0);
}
