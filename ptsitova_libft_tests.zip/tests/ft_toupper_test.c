/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_toupper_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/14 14:04:41 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_toupper_test(void)
{
	unsigned char	c;

	printf("------------------------------\n");
	printf("    ft_toupper                - If [c] is an lowercase letter, returns its uppercase equivalent. Otherwise, returns [c]\n\n");
	c = 110;
	printf("source    : %c\n\n", c);
	
	printf("toupper   : %c\n", toupper(c));
	printf("ft_toupper: %c\n\n", ft_toupper(c));
	c = 65;
	printf("source    : %c\n\n", c);
	
	printf("toupper   : %c\n", toupper(c));
	printf("ft_toupper: %c\n", ft_toupper(c));

	printf("------------------------------\n\n");
	return (0);
}
