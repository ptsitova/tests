/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_isdigit_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:28:02 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_isdigit_test(void)
{
	unsigned char	c;

	c = 50;
	printf("------------------------------\n");
	printf("    ft_isdigit                - checks for a digit. Return values are nonzero if [c] falls into the tested class, and zero if not.\n\n");

	printf("source [c]: %c\n\n", c);

	printf("isdigit   : %d\n", isdigit(c));
	printf("ft_isdigit: %d\n\n", ft_isdigit(c));
	c = 65;
	printf("source [c]: %c\n\n", c);
	printf("isdigit   : %d\n", isdigit(c));
	printf("ft_isdigit: %d\n", ft_isdigit(c));

	printf("------------------------------\n\n");
	return (0);
}
