/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_tolower_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/14 15:09:18 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_tolower_test(void)
{
	unsigned char	c;

	c = 65;
	printf("------------------------------\n");
	printf("    ft_tolower                - If [c] is an uppercase letter, returns its lowercase equivalent. Otherwise, returns [c]\n\n");
	
	printf("source    : %c\n\n", c);
	
	printf("toupper   : %c\n", tolower(c));
	printf("ft_toupper: %c\n\n", ft_tolower(c));
	c = 98;
	printf("source    : %c\n\n", c);
	
	printf("toupper   : %c\n", tolower(c));
	printf("ft_toupper: %c\n\n", ft_tolower(c));
	
	printf("------------------------------\n\n");
	return (0);
}
