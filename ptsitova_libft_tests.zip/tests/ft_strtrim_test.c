/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strtrim_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/23 09:03:40 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/23 09:03:44 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	strtrim_empty_set()
{
	char 		*s1 = strdup("bloo");
	char		*set = strdup("");
	char		*result;

	result = ft_strtrim(s1, set);

	printf("s1        : [%s]\n", s1);
	printf("set       : [%s]\n\n", set);
	
	printf("expected  : [%s]\n", s1);
	printf("ft_strtrim: [%s]\n\n", result);

	free(result);
	free(s1);
	free(set);
}

void	strtrim_empty_s1()
{
	char 		*s1 = strdup("");
	char		*set = strdup(",#. ");
	char		*result;

	result = ft_strtrim(s1, set);

	printf("s1        : [%s]\n", s1);
	printf("set       : [%s]\n\n", set);
	
	printf("expected  : []\n");
	printf("ft_strtrim: [%s]\n\n", result);

	free(result);
	free(s1);
	free(set);
}
void	strtrim_only_set_characters()
{
	char 		*s1 = strdup("#., . . # ,.#,. ,, # #. ,");
	char		*set = strdup(",#. ");
	char		*result;

	result = ft_strtrim(s1, set);

	printf("s1        : [%s]\n", s1);
	printf("set       : [%s]\n\n", set);
	
	printf("expected  : []\n");
	printf("ft_strtrim: [%s]\n\n", result);

	free(result);
	free(s1);
	free(set);
}

void	strtrim_basic()
{
	char 		*s1 = strdup("#., . . # ,.#This phrase .stays. the same, but the #rest was deleted,. ,, # #. ,");
	char		*set = strdup(",#. ");
	char		*result;

	result = ft_strtrim(s1, set);

	printf("s1        : [%s]\n", s1);
	printf("set       : [%s]\n\n", set);
	
	printf("expected  : [This phrase .stays. the same, but the #rest was deleted]\n");
	printf("ft_strtrim: [%s]\n\n", result);

	free(result);
	free(s1);
	free(set);
}

int	ft_strtrim_test(void)
{
	printf("------------------------------\n");
	printf("    ft_strtrim                - allocates memory (using malloc) and returns a copy of [s1] with characters from [set] removed from the beginning and the end.\n\n");
	
	strtrim_basic();
	strtrim_only_set_characters();
	strtrim_empty_s1();
	strtrim_empty_set();
	
	printf("------------------------------\n\n");
	return (0);
}
