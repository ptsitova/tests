/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_putendl_fd_test.c                               :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/24 13:50:56 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 14:00:06 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void	putendl_fd_basic()
{
	char	*s = strdup("What fd can be used inside this function?");
	int		file_descriptor;

	file_descriptor = 1;
	printf("source [s]          : [%s]\n", s);
	printf("file descriptor [fd]: [%d]\n\n", file_descriptor);
	
	printf("expected     : [\n%s\n]\n", s);
	printf("ft_putendl_fd: [\n");
	ft_putendl_fd(s, file_descriptor);
	printf("]\n");
	free(s);
}

int	ft_putendl_fd_test(void)
{
	printf("------------------------------\n");
	printf("    ft_putendl_fd             - outputs  the string [s] to the specified file descriptor followed by a newline\n\n");
	
	putendl_fd_basic();
	
	printf("------------------------------\n\n");
	return (0);
}
