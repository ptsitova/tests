/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_isprint_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:32:40 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_isprint_test(void)
{
	unsigned char	c;

	c = 126;
	printf("------------------------------\n");
	printf("    ft_isprint                - checks for any printable character. Return values are nonzero if [c] falls into the tested class, and zero if not.\n\n");

	printf("source [c]: %c\n\n", c);
	
	printf("isprint   : %d\n", isprint(c));
	printf("ft_isprint: %d\n\n", ft_isprint(c));
	
	c = 199;
	printf("source [c]: %c\n\n", c);
	
	printf("isdigit   : %d\n", isdigit(c));
	printf("ft_isdigit: %d\n", ft_isdigit(c));
	
	printf("------------------------------\n\n");
	return (0);
}
