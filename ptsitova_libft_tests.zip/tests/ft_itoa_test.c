/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_itoa_test.c                                     :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/23 15:16:23 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 10:53:54 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"
#include <limits.h>

void	itoa_positive()
{
	int		number;
	char	*result;

	number = 83;
	printf("source [n]: [%d]\n", number);
	result = ft_itoa(number);
	printf("ft_itoa   : [%s]\n\n", result);

	free(result);
}

void	itoa_negative()
{
	int		number;
	char	*result;

	number = -479;
	printf("source [n]: [%d]\n", number);
	result = ft_itoa(number);
	printf("ft_itoa   : [%s]\n\n", result);

	free(result);
}

void	itoa_min_int_value()
{
	int		number;
	char	*result;

	number = INT_MIN;
	printf("source [n]: [%d]\n", number);
	result = ft_itoa(number);
	printf("ft_itoa   : [%s]\n\n", result);

	free(result);
}

void	itoa_max_int_value()
{
	int		number;
	char	*result;

	number = INT_MAX;
	printf("source [n]: [%d]\n", number);
	result = ft_itoa(number);
	printf("ft_itoa   : [%s]\n\n", result);

	free(result);
}

void	itoa_zero()
{
	int		number;
	char	*result;

	number = 0;
	printf("source [n]: [%d]\n", number);
	result = ft_itoa(number);
	printf("ft_itoa   : [%s]\n", result);

	free(result);
}

int ft_itoa_test(void)
{
	printf("------------------------------\n");
	printf("    ft_itoa                   - allocates memory and returns a string representing the integer received as an argument. Negative numbers must be handled.\n\n");
	
	itoa_positive();
	itoa_negative();
	itoa_min_int_value();
	itoa_max_int_value();
	itoa_zero();
	
	printf("------------------------------\n\n");
	return (0);
}
