/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strnstr_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/20 13:10:00 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/24 15:04:44 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void strnstr_start_of_needle_overlap()
{
	char *haystack	= strdup("aaaaaaaab");
	char *needle	= strdup("aaaaab");
	size_t bytes		= 14;

	printf("finding [%s] in [%s]\nbytes [len]: %zu\n\n", needle, haystack, bytes);
	printf("strnstr    : %s\n", strnstr(haystack, needle, bytes));
	printf("ft_strnstr : %s\n\n", ft_strnstr(haystack, needle, bytes));

	free(haystack);
	free(needle);
}

int	ft_strnstr_test(void)
{
	char	*haystack = strdup("AbCdeFg");
	char	*needle = strdup("Cde");
	char	*b = strdup("oobooobb");
	char	*l = strdup("bb");
	size_t	len;

	printf("------------------------------\n");
	printf("    ft_strnstr                - locates the first occurrence of the null-terminated string [needle] in the string [haystack], where not more than [len] characters are searched.\n\n");
	len = 0;
	printf("haystack   : %s\n", haystack);
	printf("needle     : %s\n", needle);
	printf("bytes [len]: %zu\n\n", len);
	
	printf("strnstr    : %s\n", strnstr(haystack, needle, len));
	printf("ft_strnstr : %s\n\n", ft_strnstr(haystack, needle, len));
	len = 5;
	printf("haystack   : %s\n", haystack);
	printf("needle     : %s\n", needle);
	printf("bytes [len]: %zu\n\n", len);
	
	printf("strnstr    : %s\n", strnstr(haystack, needle, len));
	printf("ft_strnstr : %s\n\n", ft_strnstr(haystack, needle, len));
	len = 4;
	printf("haystack   : %s\n", b);
	printf("needle     : %s\n", l);
	printf("bytes [len]: %zu\n\n", len);

	printf("strnstr    : %s\n", strnstr(b, l, len));
	printf("ft_strnstr : %s\n\n", ft_strnstr(b, l, len));

	strnstr_start_of_needle_overlap();
	
	printf("------------------------------\n\n");
	return (0);
}
