/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_memset_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:37:02 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_memset_test(void)
{
	char	str1[] = "You can do it Polina!";
	char	str2[] = "You can do it Polina!";
	int		n;
	const char	c = '.';

	printf("------------------------------\n");
	printf("    ft_memset                 - fills the first [n] bytes of the memory area pointed to by [s] with the constant byte [c]. Return pointer to [s]\n\n");
	
	printf("source   : %s\n", str1);
	n = 3;
	printf("bytes[n] : %d\n", n);
	printf("char[c]  : [%c]\n\n", c);
	
	memset(str1 + 4, c, 3 * sizeof(char));
	printf("memset   : %s\n", str1);
	ft_memset(str2 + 4, c, 3 * sizeof(char));
	printf("ft_memset: %s\n", str2);
	
	printf("------------------------------\n\n");
	return (0);
}

// int	ft_memsettest(void)
// {
// 	int	a = 15241524;
// 	int b = 15241524;

// 	printf("original : %d\n", a);
// 	memset(&a, 48, 3 * sizeof(char));
// 	printf("memset   : %d\n", a);
// 	ft_memset(&b, 48, 3 * sizeof(char));
// 	printf("ft_memset: %d\n", b);
// 	return (0);
// }
