/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strlcat_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:38:19 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/29 09:24:12 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"
#include <unistd.h>

int	ft_strlcat_test(void)
{	
	const char	src[] = "World";
	char		dest1[100] = "Hello";
	char		dest2[100] = "Hello";
	size_t		n = 3;

	printf("------------------------------\n");
	printf("    ft_strlcat                - appends the NUL-terminated string [src] to the end of [dst]. Return the total length tried to create.\n\n");

	printf("src        : %s\n", src);
	printf("dest & dlen: %s [%zu]\n\n", dest1, ft_strlen(dest1));
	
	printf("bytes [n]  : %zu\n\n", n);
	
	printf("strlcat    : %zu [%s]\n", strlcat(dest1, src, n), dest1);
	printf("ft_strlcat : %zu [%s]\n\n", ft_strlcat(dest2, src, n), dest2);

	n = 7;
	printf("bytes [n]  : %zu\n\n", n);
	
	printf("strlcat    : %zu [%s]\n", strlcat(dest1, src, n), dest1);
	printf("ft_strlcat : %zu [%s]\n\n", ft_strlcat(dest2, src, n), dest2);
	
	char de[30]; memset(de, 0, 30);
	char de1[30]; memset(de1, 0, 30);
	memset(de, 'C', 5);
	memset(de1, 'C', 5);
	char * sr = (char *)"AAAAAAAAA";
#ifdef linux
	printf("strlcat    : %zu [%s]\n", strlcat(de, sr, -1), de);
#endif
	printf("ft_strlcat : %zu [%s]\n\n", ft_strlcat(de1, sr, -1), de1);

	char sss[20];
	memset(sss, 'f', 19);
	sss[19] = 0;
	printf("ft_strlcat expect 19 => %zu\n", ft_strlcat(de, sss, 0));
	printf("   strlcat expect 19 => %zu\n", strlcat(de, sss, 0));
	
	printf("------------------------------\n\n");
	return (0);
}
