/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_memcmp_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/20 12:46:29 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/29 10:29:50 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

static void	memcmp_basic()
{
	const char	s1[] = "AbCdeFg";
	const char	s2[] = "AbCdefg";

	printf("source [s1]: [%s] - basic check\n", s1);
	printf("source [s2]: [%s]\n", s2);
	printf("bytes [n]  : [6]\n\n");
	
	printf("memcmp     : [%d]\n", memcmp(s1, s2, 6));
	printf("ft_memcmp  : [%d]\n\n", ft_memcmp(s1, s2, 6));
	printf("---\n\n");
}

static void	memcmp_identical()
{
	const char	s1[6] = "aaa";
	const char	s2[6] = "aaa";

	printf("source [s1]: [%s] - identical memory bytes\n", s1);
	printf("source [s2]: [%s]\n", s2);
	printf("bytes [n]  : [6]\n\n");
	
	printf("memcmp     : [%d]\n", memcmp(s1, s2, 6));
	printf("ft_memcmp  : [%d]\n\n", ft_memcmp(s1, s2, 6));
	printf("---\n\n");
}

static void	memcmp_compare_zero_bytes()
{
	const char	s1[] = "abc";
	const char	s2[] = "aaa";

	printf("source [s1]: [%s] - compare 0 bytes\n", s1);
	printf("source [s2]: [%s]\n", s2);
	printf("bytes [n]  : [0]\n\n");
	
	printf("memcmp     : [%d]\n", memcmp(s1, s2, 0));
	printf("ft_memcmp  : [%d]\n\n", ft_memcmp(s1, s2, 0));
	printf("---\n\n");
}

static void	memcmp_test_array()
{
	const char	s1[] = {0, 0, 127, 0};
	const char	s2[] = {0, 0, 42, 0};

	printf("source [s1]: {0, 0, 127, 0} - test binary data with zeros\n");
	printf("source [s2]: {0, 0, 42, 0}\n");
	printf("bytes [n]  : [4]\n\n");
	
	printf("memcmp     : [%d]\n", memcmp(s1, s2, 4));
	printf("ft_memcmp  : [%d]\n\n", ft_memcmp(s1, s2, 4));
}

int	ft_memcmp_test(void)
{
	printf("------------------------------\n");
	printf("    ft_memcmp                - compares the first [n] bytes (unsigned char) of the memory areas. Returns 0 if s1 == s2, <0 if s1[]<s2[] & >0 if s1[]>s2[]\n\n");

	memcmp_basic();
	memcmp_identical();
	memcmp_compare_zero_bytes();
	memcmp_test_array();
	
	printf("------------------------------\n\n");
	return (0);
}
