/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strlen_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:41:23 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_strlen_test(void)
{
	char	str[] = "Hello World!";

	printf("------------------------------\n");
	printf("    ft_strlen                 - calculates the length of the string pointed to by [s], excluding the terminating null byte. \n\n");
	
	printf("source [s]: %s\n\n", str);
	
	printf("strlen    : %zu\n", strlen(str));
	printf("ft_strlen : %zu\n", ft_strlen(str));
	
	printf("------------------------------\n\n");
	return (0);
}
