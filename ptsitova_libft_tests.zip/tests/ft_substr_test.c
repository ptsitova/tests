/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_substr_test.c                                   :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/21 18:19:33 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/29 10:42:46 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

void substr_start_past_end()
{
	char 			*source	= strdup("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	unsigned int	start = 26;
	size_t			length = 10;
	char			*result;

	source[26] = '\0';
	result = ft_substr(source, start, length);
	printf("input    : [%s] - start is past end of the source\n", source);
	// .* = max length modifier for the string [source], that is defined by [length] >>> prints max [length] characters of the string [source]
	printf("expected : [(null)]\n");
	printf("ft_substr: [%s]\n\n", result);
	printf("---\n\n");
	free(result);
	free(source);
}

void substr_basic()
{
	char 			*source	= strdup("abcdefghijklmnopqrstuvwxyz");
	unsigned int	start = 2;
	size_t			length = 10;
	char			*result;

	result = ft_substr(source, start, length);
	printf("input    : [%s] - basic check\n", source);
	// .* = max length modifier for the string [source], that is defined by [length] >>> prints max [length] characters of the string [source]
	printf("expected : [%.*s]\n", (int)length, &source[start]);
	printf("ft_substr: [%s]\n\n", result);
	printf("---\n\n");
	// int isok = memcmp(result, &source[start], 10) == 0 
	// 				&& result[10] == '\0';
	// printf("%s\n\n", isok ? "OK" : "FAIL");
	free(result);
	free(source);
}


void substr_length_longer_than_end_of_str()
{
	char 			*source	= strdup("abcdefghijklmnopqrstuvwxyz");
	unsigned int	start = 20;
	size_t			length = 50000;
	char			*result;

	result = ft_substr(source, start, length);
	printf("input    : [%s] - length is longer than the end of the string\n", source);
	printf("expected : [%s]\n", &source[start]);
	printf("ft_substr: [%s]\n\n", result);
	printf("---\n\n");
	free(result);
	free(source);
}

void substr_start_past_end_not_allocated()
{
	char 			*source	= strdup("abcdefghijklmnopqrstuvwxyz");
	unsigned int	start = -1;
	size_t			length = 10;
	char			*result;

	result = ft_substr(source, start, length);
	printf("input    : [%s] - start is past end of the source outside of allocated space\n", source);
	// .* = max length modifier for the string [source], that is defined by [length] >>> prints max [length] characters of the string [source]
	printf("expected : [(null)]\n");
	printf("ft_substr: [%s]\n\n", result);
	printf("---\n\n");
	free(result);
	free(source);
}

// void substr_test()
// {
// 	char 			*source	= strdup("hola");
// 	unsigned int	start = 4294967295;
// 	size_t			length = 0;
// 	char			*result;

// 	result = ft_substr(source, start, length);
// 	printf("input    : [%s]\n", source);
// 	printf("expected : [(null)]\n");
// 	printf("ft_substr: [%s]\n\n", result);
// 	free(result);
// 	free(source);
// }

int	ft_substr_test(void)
{
	printf("------------------------------\n");
	printf("    ft_substr                 - allocates memory (malloc) and returns a substring from the string [s]. The substring starts at index [start] and has a max length of [len]\n\n");

	substr_basic();
	substr_length_longer_than_end_of_str();
	substr_start_past_end();
	substr_start_past_end_not_allocated();
	// substr_test();
	
	printf("------------------------------\n\n");
	return (0);
}
