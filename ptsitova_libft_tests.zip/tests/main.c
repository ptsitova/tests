/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   main.c                                             :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/14 08:30:09 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/27 14:27:01 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include "tests/tests.h"

#include <string.h>

int	main(int argc, char const *argv[])
{
	if (argc == 1 || strcmp("atoi", argv[1]) == 0)
	{
		ft_atoi_test();
	}
	if (argc == 1 || strcmp("bzero", argv[1]) == 0)
	{
		ft_bzero_test();
	}
	if (argc == 1 || strcmp("calloc", argv[1]) == 0)
	{
		ft_calloc_test();
	}
	if (argc == 1 || strcmp("isalnum", argv[1]) == 0)
	{
		ft_isalnum_test();
	}
	if (argc == 1 || strcmp("isalpha", argv[1]) == 0)
	{
		ft_isalpha_test();
	}
	if (argc == 1 || strcmp("isascii", argv[1]) == 0)
	{
		ft_isascii_test();
	}
	if (argc == 1 || strcmp("isdigit", argv[1]) == 0)
	{
		ft_isdigit_test();
	}
	if (argc == 1 || strcmp("isprint", argv[1]) == 0)
	{
		ft_isprint_test();
	}
	if (argc == 1 || strcmp("itoa", argv[1]) == 0)
	{
		ft_itoa_test();
	}
	if (argc == 1 || strcmp("memchr", argv[1]) == 0)
	{
		ft_memchr_test();
	}
	if (argc == 1 || strcmp("memcmp", argv[1]) == 0)
	{
		ft_memcmp_test();
	}
	if (argc == 1 || strcmp("memcpy", argv[1]) == 0)
	{
		ft_memcpy_test();
	}
	if (argc == 1 || strcmp("memmove", argv[1]) == 0)
	{
		ft_memmove_test();
	}
	if (argc == 1 || strcmp("memset", argv[1]) == 0)
	{
		ft_memset_test();
	}
	if (argc == 1 || strcmp("putchar", argv[1]) == 0)
	{
		ft_putchar_fd_test();
	}
	if (argc == 1 || strcmp("putendl", argv[1]) == 0)
	{
		ft_putendl_fd_test();
	}
	if (argc == 1 || strcmp("putnbr", argv[1]) == 0)
	{
		ft_putnbr_fd_test();
	}
	if (argc == 1 || strcmp("putstr", argv[1]) == 0)
	{
		ft_putstr_fd_test();
	}
	if (argc == 1 || strcmp("split", argv[1]) == 0)
	{
		ft_split_test();
	}
	if (argc == 1 || strcmp("strchr", argv[1]) == 0)
	{
		ft_strchr_test();
	}
	if (argc == 1 || strcmp("strdup", argv[1]) == 0)
	{
		ft_strdup_test();
	}
	if (argc == 1 || strcmp("striteri", argv[1]) == 0)
	{
		ft_striteri_test();
	}
	if (argc == 1 || strcmp("strjoin", argv[1]) == 0)
	{
		ft_strjoin_test();
	}
	if (argc == 1 || strcmp("strlcat", argv[1]) == 0)
	{
		ft_strlcat_test();
	}
	if (argc == 1 || strcmp("strlcpy", argv[1]) == 0)
	{
		ft_strlcpy_test();
	}
	if (argc == 1 || strcmp("strlen", argv[1]) == 0)
	{
		ft_strlen_test();
	}
	if (argc == 1 || strcmp("strmapi", argv[1]) == 0)
	{
		ft_strmapi_test();
	}
	if (argc == 1 || strcmp("strncmp", argv[1]) == 0)
	{
		ft_strncmp_test();
	}
	if (argc == 1 || strcmp("strnstr", argv[1]) == 0)
	{
		ft_strnstr_test();
	}
	if (argc == 1 || strcmp("strrchr", argv[1]) == 0)
	{
		ft_strrchr_test();
	}
	if (argc == 1 || strcmp("strtrim", argv[1]) == 0)
	{
		ft_strtrim_test();
	}
	if (argc == 1 || strcmp("substr", argv[1]) == 0)
	{
		ft_substr_test();
	}
	if (argc == 1 || strcmp("tolower", argv[1]) == 0)
	{
		ft_tolower_test();
	}
	if (argc == 1 || strcmp("toupper", argv[1]) == 0)
	{
		ft_toupper_test();
	}
	return (0);
}
