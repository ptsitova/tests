/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_atoi_test.c                                     :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/20 15:38:56 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/28 10:06:19 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

static void	atoi_positive()
{
	const char	str[] = "    +000755jd7f98649u4eiht";

	printf("source [nptr]: [%s] - basic check. positive number. skip spaces\n", str);

	printf("atoi         : %d\n", atoi(str));
	printf("ft_atoi      : %d\n\n", ft_atoi(str));
	printf("---\n\n");
}

static void	atoi_negative()
{
	const char	str[] = "-115jd7f98649u4eiht";

	printf("source [nptr]: [%s] - negative number\n", str);

	printf("atoi         : %d\n", atoi(str));
	printf("ft_atoi      : %d\n\n", ft_atoi(str));
	printf("---\n\n");
}

static void	atoi_two_symbols()
{
	const char	str[] = "-+4jd7f98649u4eiht";

	printf("source [nptr]: [%s] - two symbols in a row\n", str);

	printf("atoi         : %d\n", atoi(str));
	printf("ft_atoi      : %d\n\n", ft_atoi(str));
	printf("---\n\n");
}

static void	atoi_max_value()
{
	const char	str[] = "2147483647-max-int";

	printf("source [nptr]: [%s] - MAX value of integer\n", str);

	printf("atoi         : %d\n", atoi(str));
	printf("ft_atoi      : %d\n\n", ft_atoi(str));
	printf("---\n\n");
}

static void	atoi_min_value()
{
	const char	str[] = "-2147483648-min-int";

	printf("source [nptr]: [%s] - MIN value of integer\n", str);

	printf("atoi         : %d\n", atoi(str));
	printf("ft_atoi      : %d\n\n", ft_atoi(str));
}

int	ft_atoi_test(void)
{
	printf("------------------------------\n");
	printf("    ft_atoi                   - converts the initial portion of the string pointed to by [nptr] to int.\n\n");

	atoi_positive();
	atoi_negative();
	atoi_two_symbols();
	atoi_max_value();
	atoi_min_value();

	printf("------------------------------\n\n");
	return (0);
}
