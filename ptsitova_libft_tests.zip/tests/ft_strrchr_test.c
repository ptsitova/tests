/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strrchr_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/20 10:37:50 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/28 09:08:59 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

static void	strrchr_basic()
{
	char	str[] = "This is a string";
	
	printf("source [s]   : [%s] - basic check\n", str);
	printf("character [c]: [s]\n\n");
	
	printf("strrchr      : %s\n", strrchr(str, 's'));
	printf("ft_strrchr   : %s\n\n", ft_strrchr(str, 's'));
	printf("---\n\n");
}

static void	strrchr_char_is_not_in_src()
{
	char	str[] = "This is a string";
	
	printf("source [s]   : [%s] - character is not in source\n", str);
	printf("character [c]: [z]\n\n");
	
	printf("strrchr      : %s\n", strrchr(str, 'z'));
	printf("ft_strrchr   : %s\n\n", ft_strrchr(str, 'z'));
	printf("---\n\n");
}

static void	strrchr_first_char()
{
	char	str[] = "bonjour";
	
	printf("source [s]   : [%s] - checks first character\n", str);
	printf("character [c]: [b]\n\n");
	
	printf("strrchr      : %s\n", strrchr(str, 'b'));
	printf("ft_strrchr   : %s\n\n", ft_strrchr(str, 'b'));
	printf("---\n\n");
}

static void	strrchr_last_char()
{
	char	str[] = "bonjour";
	
	printf("source [s]   : [%s] - checks last character\n", str);
	printf("character [c]: [r]\n\n");
	
	
	printf("strrchr      : %s\n", strrchr(str, 'r'));
	printf("ft_strrchr   : %s\n\n", ft_strrchr(str, 'r'));
	printf("---\n\n");
}

static void	strrchr_src_is_null()
{
	char	*s = strdup("\0");
	
	printf("source [s]   : [%s] - empty source\n", s);
	printf("character [c]: [b]\n\n");
	
	printf("strrchr      : %s\n", strrchr(s, 'b'));
	printf("ft_strrchr   : %s\n\n", ft_strrchr(s, 'b'));
	printf("---\n\n");
	free(s);
}

static void	strrchr_char_is_null()
{
	char	*s = strdup("Check the null");
	
	printf("source [s]   : [%s] - character == ['\\0']\n", s);
	printf("character [c]: ['\\0']\n\n");
	
	printf("strrchr      : %s\n", strrchr(s, '\0'));
	printf("ft_strrchr   : %s\n\n", ft_strrchr(s, '\0'));
	free(s);
}

int			ft_strrchr_test(void)
{
	printf("------------------------------\n");
	printf("    ft_strrchr                 - returns a pointer to the last occurrence of the character [c] in the string [s]\n\n");
	
	strrchr_basic();
	strrchr_char_is_not_in_src();
	strrchr_first_char();
	strrchr_last_char();
	strrchr_src_is_null();
	strrchr_char_is_null();
	
	printf("------------------------------\n\n");
	return (0);
}
