/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_isalnum_test.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: ptsitova <ptsitova@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2025/10/13 12:19:03 by ptsitova      #+#    #+#                 */
/*   Updated: 2025/10/21 18:20:47 by ptsitova      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "tests.h"

int	ft_isalnum_test(void)
{
	unsigned char	c;

	c = ':';
	printf("------------------------------\n");
	printf("    ft_isalnum                - checks for an alphanumeric character. Return values are nonzero if [c] falls into the tested class, and zero if not.\n\n");
	
	printf("source [c]: %c\n\n", c);
	
	printf("isalnum   : %d\n", isalnum(c));
	printf("ft_isalnum: %d\n", ft_isalnum(c));
	
	printf("------------------------------\n\n");
	return (0);
}
